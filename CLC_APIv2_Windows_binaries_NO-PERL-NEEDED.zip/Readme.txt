To run the Windows binaries (no PERL needed):
Copy the three (3) DLL files into your path (like: C:\Windows\System32\)
then simply click on the EXE to run it (maximize to full screen if desired).